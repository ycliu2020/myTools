mex -v -f mexopts.R2008a.bat -output ../private/vanilla_mexnc mexgateway.c netcdf2.c netcdf3.c common.c
