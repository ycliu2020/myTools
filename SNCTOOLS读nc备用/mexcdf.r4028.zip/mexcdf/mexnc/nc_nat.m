function nc_datatype = nc_nat()
% NC_NAT:  returns constant corresponding to NC_NAT enumerated constant in netcdf.h
%
% USAGE:  nc_datatype = nc_nat;
%

nc_datatype = 0;
return




